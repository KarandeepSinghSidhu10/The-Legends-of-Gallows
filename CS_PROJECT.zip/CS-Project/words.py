import random

DIFFICULTY_LEVELS = ["Easy", "Medium", "Hard"]

SHARED_CATEGORIES = [
    "Animals",
    "Objects",
    "Places",
    "Characters",
    "Special Items"
]

# Structure: ROLE_WORDS["RoleName"]["CategoryName"]["DifficultyLevel"] = [words]
ROLE_WORDS = {
    "Warrior": {
        "Animals": {
            "Easy": ["boar", "wolf", "bear", "dog", "ram"],
            "Medium": ["stag", "hound", "steed", "panther", "falcon"],
            "Hard": ["mastiff", "griffon", "wyvern", "chimera", "grizzly"]
        },
        "Objects": {
            "Easy": ["sword", "shield", "axe", "bow", "mail"],
            "Medium": ["armor", "helmet", "banner", "spear", "dagger"],
            "Hard": ["battle-axe", "longspear", "sigil", "cuirass", "greatsword"]
        },
        "Places": {
            "Easy": ["fort", "keep", "camp", "gate", "wall"],
            "Medium": ["barracks", "arena", "outpost", "ruins", "tower"],
            "Hard": ["citadel", "battlefield", "wasteland", "stronghold", "rampart"]
        },
        "Characters": {
            "Easy": ["guard", "chief", "hero", "knight", "squire"],
            "Medium": ["soldier", "captain", "champion", "lieutenant", "general"],
            "Hard": ["commander", "mercenary", "legionary", "gladiator", "warlord"]
        },
        "Special Items": {
            "Easy": ["war-cry", "rune", "pact", "badge", "sash"],
            "Medium": ["battlehelm", "gauntlet", "vambrace", "scabbard", "talisman"],
            "Hard": ["battle-axe", "longspear", "war-banner", "bravery", "loyalty"]
        }
    },
    # ... (include all the other roles' word data from your original code)
    # For brevity, I'm showing just the Warrior role structure
}

def get_word_for(role_name, category_name, difficulty):
    """
    Return a random word based on role name, category, and difficulty.
    """
    # 1. Try to get the specific word list
    words_list = ROLE_WORDS.get(role_name, {}).get(category_name, {}).get(difficulty, [])
    
    # 2. Fallback check (should not be needed with complete lists)
    if not words_list:
        words_from_all_difficulties = []
        category_data = ROLE_WORDS.get(role_name, {}).get(category_name, {})
        for level in DIFFICULTY_LEVELS:
            words_from_all_difficulties.extend(category_data.get(level, []))
        words_list = words_from_all_difficulties
        
    if not words_list:
        all_words = []
        for role_data in ROLE_WORDS.values():
            for category_data in role_data.values():
                for level_words in category_data.values():
                    all_words.extend(level_words)
        if not all_words:
            return "oracle" # Default fail-safe word
        return random.choice(all_words).replace(" ", "").replace("-", "").lower()

    # Select word and clean up (remove hyphens/spaces and lower case)
    w = random.choice(words_list)
    return w.replace(" ", "").replace("-", "").lower()